//
//  RoyaIAApp.swift
//  RoyaIA
//
//  Created by Alumno on 04/09/25.
//

import SwiftUI

@main
struct RoyaIAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
