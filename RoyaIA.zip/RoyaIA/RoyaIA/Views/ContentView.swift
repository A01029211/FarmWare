//
//  ContentView.swift
//  RoyaIA
//
//  Created by Alumno on 04/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            MainView()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
