//
//  EducacionalPageView.swift
//  RoyaIA
//
//  Created by Alumno on 04/09/25.
//

import SwiftUI

struct EducacionalPageView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    EducacionalPageView()
}
